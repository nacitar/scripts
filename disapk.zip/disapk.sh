#!/bin/bash

# by: jmcintosh

# general
# usage: ./disaph.sh bla.apk

# to use the alternate decompiler, after attempting the primary one, to manually get different results
# usage: ./disaph.sh -g bla.apk

get_real_path()
{
	local rel_path="$@"
	if [ -f "$rel_path" ]; then
		local ARGDIR="$(dirname "$rel_path")"
		if [ -d "$ARGDIR" ] && pushd "$ARGDIR" &>/dev/null; then
			local thepath="$(pwd)"
			if [ "$thepath" == "/" ]; then
				thepath=""
			fi
			echo "$thepath/$(basename "$rel_path")"
			popd &>/dev/null
			return 0
		fi
	fi
	return 1
}

GUI_DECOMP=0
while [ 1 ]; do
	if [ "$1" == "-g" ] || [ "$1" == "-G" ]; then
		GUI_DECOMP=1
		shift
		continue
	fi
	break
done

	
APK_ARG="$1"

THIS_FILE="$(get_real_path "$0")"
THIS_DIR="$(dirname "$THIS_FILE")"
INPUT_FILE="$(get_real_path "$1")"
INPUT_BASENAME="$(basename "$INPUT_FILE")"

INPUT_BASENAME_NO_EXT="${INPUT_BASENAME%.[aA][pP][kK]}" #



JAR_INPUT=0
if [ "$INPUT_BASENAME" == "$INPUT_BASENAME_NO_EXT" ]; then
	INPUT_BASENAME_NO_EXT="${INPUT_BASENAME%.[jJ][aA][rR]}" #
	if [ "$INPUT_BASENAME" == "$INPUT_BASENAME_NO_EXT" ]; then
		echo "Only jar and apk input files are supported."
		exit 1
	else
		JAR_INPUT=1
	fi
fi


CWD_PATH="$(pwd)" #
OUT_DIR="$CWD_PATH/$INPUT_BASENAME_NO_EXT.disapk" #
OUT_SRC_DIR="$OUT_DIR/src" #
OUT_TMP_DIR="$OUT_DIR/decomp_tmp" #
OUT_UNJAR_DIR="$OUT_TMP_DIR/unjar" #

if [ "$JAR_INPUT" == "0" ]; then
	JAR_FILE="$OUT_TMP_DIR/${INPUT_BASENAME_NO_EXT}_dex2jar.jar"
else
	JAR_FILE="$INPUT_FILE"
fi

TOOLS_DIR="$THIS_DIR/tools_disapk" #

DECOMP_LOG="$OUT_TMP_DIR/jad_decompilation.log" #



if [ -z "$THIS_FILE" ]; then
	echo "Something's broken with an internal function; we can't find our own file path!"
	exit 2
fi

if [ -z "$INPUT_FILE" ]; then
	echo "APK file could not be located!"
	exit 3
fi


# ALLOW RUNNING GUI DECOMPILER
if [ "$GUI_DECOMP" == "1" ]; then
	echo ""
	echo "==============================="
	echo "    Running GUI Decompiler     "
	echo "==============================="
	echo "Running..."
	if ! [ -f "$JAR_FILE" ]; then
		echo "Cannot open GUI decompiler unless JAR file exists!  Run this program without the flag once, or pass in a jar file instead."
		exit 4
	fi
	if ! pushd "$TOOLS_DIR/jd-gui" &>/dev/null; then
		echo "Couldn't change to jd-gui direcotry!"
		exit 5
	fi
	./jd-gui "$JAR_FILE"
	popd &>/dev/null
	exit $?
fi

# MAKE SURE WE DON'T STEP ON OUR TOES
if [ -d "$OUT_DIR" ] || [ -f "$OUT_DIR" ]; then
	echo "Output directory for source already exists! Please delete \"$OUT_DIR\" or choose a new path!"
	exit 6
fi

if [ "$JAR_INPUT" == "0" ]; then
	# APK TO XML AND SMALI (this creates the out directory)
	echo ""
	echo "==============================="
	echo "Converting APK to XML and SMALI"
	echo "==============================="
	echo "Running..."

	if ! java -jar "$TOOLS_DIR/apktool/apktool.jar" d "$INPUT_FILE" "$OUT_DIR"; then
		echo ""
		echo "Error decompiling apk to xml and smali!  Will still attempt java decompilation."
		echo ""
	fi


	if ! mkdir "$OUT_TMP_DIR"; then
		echo "Failed to create temporary output directory!"
		exit 7
	fi

	# APK TO JAR
	echo ""
	echo "==============================="
	echo "     Converting APK to JAR     "
	echo "==============================="
	echo "Running..."

	if ! pushd "$OUT_TMP_DIR" &>/dev/null; then
		echo "Error swapping to temporary directory!"
		exit 8
	fi

	if ! "$TOOLS_DIR/dex2jar/dex2jar.sh" "$INPUT_FILE"; then
		echo "Error converting apk to jar file!  \"$JAR_FILE\""
		exit 9
	fi

	if ! popd &>/dev/null; then
		echo "Error swapping back to original directory!"
		exit 10
	fi
	if ! [ -f "$JAR_FILE" ]; then
		echo "Couldn't find output jar file!  \"$JAR_FILE\""
		exit 11
	fi
else
	# if it's a jar file, we need to create the output directory
	if ! [ -d "$OUT_DIR" ] && ! mkdir "$OUT_DIR"; then
		echo "Could not create output directory, aborting!"
		exit 12
	fi

fi

# EXTRACT JAR
if ! mkdir "$OUT_UNJAR_DIR"; then
	echo "Failed to create output unjar subdirectory!"
	exit 13
fi
echo ""
echo "==============================="
echo "      Extracting Jar File      "
echo "==============================="
echo "Running..."

if ! unzip -q "$JAR_FILE" -d "$OUT_UNJAR_DIR"; then
	echo "Error extract jar file to temporary folder!"
	exit 14
fi

# JAVA DECOMPILATION
if ! mkdir "$OUT_SRC_DIR"; then
	echo "Failed to create output src/ subdirectory!"
	exit 15
fi
echo ""
echo "==============================="
echo "     Decompiling Jar File      "
echo "==============================="
echo "Running..."

if ! "$TOOLS_DIR/jad/jad" -d "$OUT_SRC_DIR" -ff -r -lnc -o -s java "$OUT_UNJAR_DIR"/**/*.class 2>"$DECOMP_LOG"; then
	echo ""
	echo "Error decompiling jar file, look at \"$DECOMP_LOG\" for more information!"
	exit 16
else
	echo ""
	echo "LOOK AT THE DECOMPILATION LOG IF YOU WANT TO KNOW HOW WELL IT WORKED!"
	echo "Decompilation complete; look at \"$DECOMP_LOG\" for more information."
fi

echo ""
echo "==============================="
echo "     Decompilation Errors      "
echo "==============================="
echo "BEGIN"
cat "$DECOMP_LOG"
echo "END"



echo ""
echo "NOTE: You may delete the entire directory \"$OUT_TMP_DIR\", as it is only for holding temporary files for this process."
exit 0

